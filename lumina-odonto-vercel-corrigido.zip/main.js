import * as THREE from "./three.module.min.js";

const root = document.documentElement;
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
root.classList.remove("no-js");
root.classList.add("js");

const treatments = {
  scanner: {
    title: "Scanner 3D",
    copy: "Captura precisa da arcada em poucos minutos, sem moldes tradicionais e com visualização imediata."
  },
  design: {
    title: "Design do sorriso",
    copy: "Proporção, cor e linha do sorriso são simuladas antes do tratamento para alinhar desejo e viabilidade."
  },
  controle: {
    title: "Acompanhamento clínico",
    copy: "Cada etapa fica documentada com fotos, exames e retornos planejados para preservar o resultado."
  }
};

function syncPointer(event) {
  const x = `${event.clientX}px`;
  const y = `${event.clientY}px`;
  root.style.setProperty("--x", x);
  root.style.setProperty("--y", y);
}

function createSparkles() {
  const field = document.querySelector(".sparkle-field");
  if (!field) return;

  const count = window.innerWidth < 640 ? 34 : 58;
  const fragment = document.createDocumentFragment();

  for (let index = 0; index < count; index += 1) {
    const dot = document.createElement("span");
    const size = 3 + Math.random() * 7;
    dot.style.setProperty("--left", `${Math.random() * 100}%`);
    dot.style.setProperty("--top", `${Math.random() * 88}%`);
    dot.style.setProperty("--size", `${size}px`);
    dot.style.setProperty("--delay", `${Math.random() * 5}s`);
    dot.style.setProperty("--duration", `${3.4 + Math.random() * 4.5}s`);
    fragment.append(dot);
  }

  field.append(fragment);
}

function createSparkTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 96;
  canvas.height = 96;
  const context = canvas.getContext("2d");
  const gradient = context.createRadialGradient(48, 48, 0, 48, 48, 48);
  gradient.addColorStop(0, "rgba(255,255,255,1)");
  gradient.addColorStop(0.18, "rgba(179,242,255,0.95)");
  gradient.addColorStop(0.42, "rgba(69,201,255,0.38)");
  gradient.addColorStop(1, "rgba(69,201,255,0)");
  context.fillStyle = gradient;
  context.fillRect(0, 0, 96, 96);
  return new THREE.CanvasTexture(canvas);
}

function makeTooth(material) {
  const tooth = new THREE.Group();
  const crownGeometry = new THREE.SphereGeometry(0.72, 56, 36);
  const lobeData = [
    [-0.48, 0.38, 0.08, 0.76, 0.58, 0.64],
    [0.48, 0.38, 0.08, 0.76, 0.58, 0.64],
    [-0.26, 0.0, 0.12, 0.72, 0.62, 0.68],
    [0.26, 0.0, 0.12, 0.72, 0.62, 0.68],
    [0, 0.22, -0.2, 0.92, 0.72, 0.72]
  ];

  lobeData.forEach(([x, y, z, sx, sy, sz]) => {
    const lobe = new THREE.Mesh(crownGeometry, material);
    lobe.position.set(x, y, z);
    lobe.scale.set(sx, sy, sz);
    lobe.castShadow = true;
    tooth.add(lobe);
  });

  const rootMaterial = material.clone();
  rootMaterial.roughness = 0.24;
  const rootGeometry = new THREE.CapsuleGeometry(0.27, 0.92, 18, 32);
  const rootLeft = new THREE.Mesh(rootGeometry, rootMaterial);
  rootLeft.position.set(-0.28, -0.75, 0.04);
  rootLeft.rotation.z = -0.16;
  rootLeft.scale.set(0.82, 1.18, 0.74);

  const rootRight = new THREE.Mesh(rootGeometry, rootMaterial);
  rootRight.position.set(0.28, -0.75, 0.04);
  rootRight.rotation.z = 0.16;
  rootRight.scale.set(0.82, 1.18, 0.74);

  const groove = new THREE.Mesh(
    new THREE.TorusGeometry(0.64, 0.012, 12, 96),
    new THREE.MeshBasicMaterial({ color: 0x7de8ff, transparent: true, opacity: 0.38 })
  );
  groove.position.set(0, 0.12, 0.48);
  groove.scale.set(1, 0.25, 1);

  tooth.add(rootLeft, rootRight, groove);
  tooth.scale.set(1.12, 1.12, 1.12);
  tooth.rotation.set(0.1, -0.44, 0.08);
  tooth.position.set(1.3, -0.05, 0);
  return tooth;
}

function makeOrbit(color, radiusX, radiusY, z, rotation) {
  const points = [];
  for (let index = 0; index <= 96; index += 1) {
    const angle = (index / 96) * Math.PI * 2;
    points.push(new THREE.Vector3(Math.cos(angle) * radiusX, Math.sin(angle) * radiusY, z));
  }

  const curve = new THREE.CatmullRomCurve3(points, true);
  const geometry = new THREE.TubeGeometry(curve, 160, 0.009, 8, true);
  const material = new THREE.MeshBasicMaterial({
    color,
    transparent: true,
    opacity: 0.58,
    blending: THREE.AdditiveBlending
  });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.rotation.set(rotation[0], rotation[1], rotation[2]);
  return mesh;
}

function initThreeScene() {
  const canvas = document.querySelector("#dental-stage");
  if (!canvas || reducedMotion) return;

  const renderer = new THREE.WebGLRenderer({
    canvas,
    alpha: true,
    antialias: true,
    preserveDrawingBuffer: true,
    powerPreference: "high-performance"
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
  camera.position.set(0, 0.2, 6);

  scene.add(new THREE.AmbientLight(0xffffff, 1.55));

  const key = new THREE.DirectionalLight(0xffffff, 2.2);
  key.position.set(-3.4, 4.2, 5);
  scene.add(key);

  const rim = new THREE.PointLight(0x3dd4ff, 3.6, 9);
  rim.position.set(3, 1.6, 2.8);
  scene.add(rim);

  const toothMaterial = new THREE.MeshPhysicalMaterial({
    color: 0xf9fdff,
    roughness: 0.17,
    metalness: 0,
    clearcoat: 0.92,
    clearcoatRoughness: 0.13,
    transmission: 0.08,
    thickness: 0.55,
    transparent: true,
    opacity: 0.94
  });

  const heroObject = new THREE.Group();
  const tooth = makeTooth(toothMaterial);
  const orbitA = makeOrbit(0x61ddff, 1.55, 0.54, 0, [0.18, 0.6, -0.2]);
  const orbitB = makeOrbit(0x0f84ff, 1.3, 0.42, 0.04, [0.66, -0.36, 0.6]);
  const orbitC = makeOrbit(0xffffff, 1.82, 0.62, -0.1, [-0.42, 0.26, 0.1]);
  heroObject.add(tooth, orbitA, orbitB, orbitC);
  scene.add(heroObject);

  const crystalGeometry = new THREE.OctahedronGeometry(0.055, 0);
  const crystalMaterial = new THREE.MeshBasicMaterial({
    color: 0xdff9ff,
    transparent: true,
    opacity: 0.72,
    blending: THREE.AdditiveBlending
  });

  const crystals = Array.from({ length: 38 }, () => {
    const crystal = new THREE.Mesh(crystalGeometry, crystalMaterial);
    crystal.position.set(
      1.3 + (Math.random() - 0.5) * 4.6,
      (Math.random() - 0.5) * 2.5,
      (Math.random() - 0.5) * 1.8
    );
    crystal.scale.setScalar(0.7 + Math.random() * 2.2);
    scene.add(crystal);
    return {
      mesh: crystal,
      speed: 0.25 + Math.random() * 0.65,
      drift: Math.random() * Math.PI * 2
    };
  });

  const particleCount = window.innerWidth < 640 ? 170 : 300;
  const positions = new Float32Array(particleCount * 3);
  const speeds = new Float32Array(particleCount);
  for (let index = 0; index < particleCount; index += 1) {
    const stride = index * 3;
    positions[stride] = 1.1 + (Math.random() - 0.5) * 6.4;
    positions[stride + 1] = -1.8 + Math.random() * 3.6;
    positions[stride + 2] = -1.8 + Math.random() * 2.6;
    speeds[index] = 0.002 + Math.random() * 0.006;
  }

  const particleGeometry = new THREE.BufferGeometry();
  particleGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const particleMaterial = new THREE.PointsMaterial({
    map: createSparkTexture(),
    color: 0xbff5ff,
    size: 0.085,
    transparent: true,
    opacity: 0.82,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  });
  const particles = new THREE.Points(particleGeometry, particleMaterial);
  scene.add(particles);

  const pointer = new THREE.Vector2(0, 0);
  window.addEventListener("pointermove", (event) => {
    pointer.x = (event.clientX / window.innerWidth - 0.5) * 0.8;
    pointer.y = (event.clientY / window.innerHeight - 0.5) * -0.55;
  });

  function resize() {
    const { clientWidth, clientHeight } = canvas;
    renderer.setSize(clientWidth, clientHeight, false);
    camera.aspect = clientWidth / Math.max(clientHeight, 1);
    camera.updateProjectionMatrix();
    heroObject.scale.setScalar(clientWidth < 640 ? 0.72 : clientWidth < 980 ? 0.86 : 1);
    heroObject.position.x = clientWidth < 640 ? 0.4 : 0;
    heroObject.position.y = clientWidth < 640 ? -0.28 : 0;
  }

  const clock = new THREE.Clock();
  function render() {
    const elapsed = clock.getElapsedTime();
    heroObject.rotation.y += (pointer.x - heroObject.rotation.y) * 0.035;
    heroObject.rotation.x += (pointer.y - heroObject.rotation.x) * 0.035;
    tooth.rotation.y = -0.44 + Math.sin(elapsed * 0.7) * 0.08;
    tooth.position.y = -0.05 + Math.sin(elapsed * 1.2) * 0.05;
    orbitA.rotation.z += 0.004;
    orbitB.rotation.z -= 0.005;
    orbitC.rotation.z += 0.0025;

    for (let index = 0; index < particleCount; index += 1) {
      const stride = index * 3;
      positions[stride + 1] += speeds[index];
      positions[stride] += Math.sin(elapsed * 0.6 + index) * 0.0009;
      if (positions[stride + 1] > 2) {
        positions[stride + 1] = -1.8;
      }
    }
    particleGeometry.attributes.position.needsUpdate = true;

    crystals.forEach((crystal, index) => {
      crystal.mesh.rotation.x += 0.01 * crystal.speed;
      crystal.mesh.rotation.y += 0.015 * crystal.speed;
      crystal.mesh.position.y += Math.sin(elapsed * crystal.speed + crystal.drift) * 0.0009;
      crystal.mesh.material.opacity = 0.38 + Math.sin(elapsed * 1.8 + index) * 0.18;
    });

    renderer.render(scene, camera);
    if (!root.classList.contains("three-ready")) {
      root.classList.add("three-ready");
    }
    window.requestAnimationFrame(render);
  }

  resize();
  window.addEventListener("resize", resize);
  render();
}

function initReveal() {
  const elements = document.querySelectorAll(".reveal");
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.16 });

  elements.forEach((element) => observer.observe(element));
}

function initCounters() {
  const counters = document.querySelectorAll("[data-counter]");
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      const element = entry.target;
      const target = Number(element.dataset.counter);
      const suffix = element.dataset.suffix || "";
      let value = 0;
      const step = Math.max(1, Math.ceil(target / 52));

      const tick = () => {
        value = Math.min(target, value + step);
        element.textContent = `${value}${suffix}`;
        if (value < target) window.requestAnimationFrame(tick);
      };

      tick();
      observer.unobserve(element);
    });
  }, { threshold: 0.55 });

  counters.forEach((counter) => observer.observe(counter));
}

function formatTimeLabel(value) {
  const labels = {
    "manhã": "pela manhã",
    tarde: "à tarde",
    noite: "à noite"
  };
  return labels[value] || value;
}

function initTilt() {
  if (reducedMotion) return;

  document.querySelectorAll(".tilt-card").forEach((card) => {
    card.addEventListener("pointermove", (event) => {
      const rect = card.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width;
      const y = (event.clientY - rect.top) / rect.height;
      const rotateX = (0.5 - y) * 8;
      const rotateY = (x - 0.5) * 10;
      card.style.transform = `perspective(900px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`;
      card.style.setProperty("--card-x", `${x * 100}%`);
      card.style.setProperty("--card-y", `${y * 100}%`);
    });

    card.addEventListener("pointerleave", () => {
      card.style.transform = "";
    });
  });
}

function initMagneticButtons() {
  if (reducedMotion) return;

  document.querySelectorAll(".magnetic").forEach((button) => {
    button.addEventListener("pointermove", (event) => {
      const rect = button.getBoundingClientRect();
      const x = (event.clientX - rect.left - rect.width / 2) * 0.16;
      const y = (event.clientY - rect.top - rect.height / 2) * 0.22;
      button.style.transform = `translate(${x}px, ${y}px)`;
    });

    button.addEventListener("pointerleave", () => {
      button.style.transform = "";
    });
  });
}

function initTreatmentSwitch() {
  const title = document.querySelector("#treatment-title");
  const copy = document.querySelector("#treatment-copy");
  const buttons = document.querySelectorAll(".switch-button");
  if (!title || !copy || !buttons.length) return;

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const treatment = treatments[button.dataset.treatment];
      if (!treatment) return;

      buttons.forEach((item) => item.classList.toggle("is-active", item === button));
      title.textContent = treatment.title;
      copy.textContent = treatment.copy;
    });
  });
}

function initBookingForm() {
  const form = document.querySelector(".booking-form");
  if (!form) return;

  const service = form.elements.service;
  const time = form.elements.time;
  const sensitivity = form.elements.sensitivity;
  const result = form.querySelector(".form-result");
  const readout = form.querySelector(".range-readout");

  const update = () => {
    const level = Number(sensitivity.value);
    const comfort = level > 7 ? "protocolo de conforto avançado" : level > 4 ? "protocolo de conforto moderado" : "protocolo de conforto leve";
    readout.textContent = `${level} / 10`;
    result.textContent = `Plano inicial: ${service.value} ${formatTimeLabel(time.value)}, com ${comfort}.`;
  };

  ["input", "change"].forEach((eventName) => {
    form.addEventListener(eventName, update);
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const name = form.elements.name.value.trim() || "Paciente";
    result.textContent = `${name}, seu pré-agendamento foi preparado para ${service.value} ${formatTimeLabel(time.value)}.`;
    result.animate(
      [
        { transform: "scale(0.98)", boxShadow: "0 0 0 rgba(66,201,255,0)" },
        { transform: "scale(1)", boxShadow: "0 0 34px rgba(66,201,255,0.32)" }
      ],
      { duration: 420, easing: "ease-out" }
    );
  });

  update();
}

window.addEventListener("pointermove", syncPointer);
createSparkles();
initThreeScene();
initReveal();
initCounters();
initTilt();
initMagneticButtons();
initTreatmentSwitch();
initBookingForm();
